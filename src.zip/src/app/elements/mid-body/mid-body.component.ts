import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mid-body',
  templateUrl: './mid-body.component.html',
  styleUrls: ['./mid-body.component.css']
})
export class MidBodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
