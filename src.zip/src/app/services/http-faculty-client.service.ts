import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Faculty } from '../models/faculty';


@Injectable({
  providedIn: 'root'
})
export class HttpFacultyClientService {

  constructor(private httpClient:HttpClient) { }

  facultyList():Observable<Faculty[]>{
    return this.httpClient.get<Faculty[]>('http://localhost:9090/api/faculty/all');
  }

  facultyCreate(faculty: Faculty):Observable<Faculty>{
    return this.httpClient.post<Faculty>('http://localhost:9090/api/faculty/add', faculty);
  }

  facultyDelete(facultyId: number):Observable<Faculty>{
    return this.httpClient.delete<Faculty>('http://localhost:9090/api/faculty/delete/'+facultyId);
  }

  public  facultyListById(facultyId:number):Observable<Faculty>{
    return this.httpClient.get<Faculty>("http://localhost:9090/api/faculty/byId/"+facultyId);
  }
  
  public facultyUpdate(faculty: Faculty):Observable<Faculty>{
    return this.httpClient.put<Faculty>("http://localhost:9090/api/faculty/update", faculty);
  }

}

