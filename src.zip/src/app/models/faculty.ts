export class Faculty {
    constructor(
        public facultyId:number,
        public userName:string,
        public totalClass:string,
        public subjectList:string,
        public subject:Subject
     ){}


}
export class Subject {
    constructor(
        
        public subjectList:string=""
        
    ){

    }
}