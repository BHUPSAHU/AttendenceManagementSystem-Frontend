import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Faculty, Subject } from 'src/app/models/faculty';
import { HttpFacultyClientService } from 'src/app/services/http-faculty-client.service';

@Component({
  selector: 'app-faculty-create',
  templateUrl: './faculty-create.component.html',
  styleUrls: ['./faculty-create.component.css']
})
export class FacultyCreateComponent implements OnInit {

  constructor(private httpClientService:HttpFacultyClientService,private router:Router) { }
  submitted:boolean = false;
  subject :Subject = new Subject("");
  faculty :Faculty = new Faculty(0,"","","",this.subject);
  addFacultyForm : FormGroup = new FormGroup({});
  facultyObs :Observable<Faculty> = new Observable<Faculty>();
  subjectObs :Observable<Faculty> = new Observable<Faculty>();


  ngOnInit(): void {
  }

  onSubmit() {
    this.submitted = true;
    
    this.faculty.subject.subjectList = this.faculty.subjectList;
    console.log(this.faculty);
    this.facultyObs =this.httpClientService.facultyCreate(this.faculty);
    
    this.facultyObs.subscribe(data =>{
      console.log(data);
      alert("Student Added Successfully.")
    })
    this.router.navigate(['/faculty/list']);
  }


}
