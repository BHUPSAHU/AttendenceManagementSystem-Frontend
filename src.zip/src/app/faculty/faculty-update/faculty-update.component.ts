import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Faculty, Subject } from 'src/app/models/faculty';
import { HttpFacultyClientService } from 'src/app/services/http-faculty-client.service';

@Component({
  selector: 'app-faculty-update',
  templateUrl: './faculty-update.component.html',
  styleUrls: ['./faculty-update.component.css']
})
export class FacultyUpdateComponent implements OnInit {

  id:number = 0 ;
  submitted:boolean =false;
  subject :Subject = new Subject("");
  faculty :Faculty = new Faculty(0,"","","",this.subject);
  facultyObs : Observable<Faculty> = new Observable<Faculty>();
  sid:string =''


  constructor(private httpClientService:HttpFacultyClientService,private route: ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.sid = this.route.snapshot.params['id'];
    this.id = Number.parseInt(this.sid);
    this.faculty =new Faculty(this.id,"","","",this.subject); 
    this.httpClientService.facultyListById(this.id).subscribe(data =>{
      this.faculty=data;
    },error => console.log(error));

  }

  onSubmit() {
    console.log("update")
    this.submitted = true;
    this.facultyObs =this.httpClientService.facultyUpdate(this.faculty);
    this.facultyObs.subscribe(data =>{
      alert("Student Updated Successfully.")
    })
    this.router.navigate(['faculty/list']);
  } 

  list(){
    this.router.navigate(['faculty/list']);
  }


}
