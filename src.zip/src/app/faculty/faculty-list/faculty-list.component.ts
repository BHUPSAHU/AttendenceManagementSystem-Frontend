import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Faculty, Subject } from 'src/app/models/faculty';
import { HttpFacultyClientService } from 'src/app/services/http-faculty-client.service';

@Component({
  selector: 'app-faculty-list',
  templateUrl: './faculty-list.component.html',
  styleUrls: ['./faculty-list.component.css']
})
export class FacultyListComponent implements OnInit {
  facultys :Faculty[] = [];
  subject :Subject = new Subject("");
  faculty :Faculty = new Faculty(0,"","","",this.subject);

  facultysObs:Observable<Faculty[]> = new Observable<Faculty[]>();
  findFacultyObs:Observable<Faculty> = new Observable<Faculty>();
  delFacultyObs:Observable<Faculty> = new Observable<Faculty>();
  upFacultyObs : Observable<Faculty> = new Observable<Faculty>();

  constructor(private httpClientService:HttpFacultyClientService,private router:Router) { }

  ngOnInit(): void {
    this.facultysObs = this.httpClientService.facultyList();
    this.facultysObs.subscribe(data => {
      console.log(data);
      this.facultys = data;
    });
  }

  facultyDelete(id:number):void{
    this.findFacultyObs=this.httpClientService.facultyListById(id)
    this.findFacultyObs.subscribe(data=>{
      this.faculty = data
    })
    this.delFacultyObs= this.httpClientService.facultyDelete(id);
    alert("Student deleted successfully");
    location.reload();
    this.delFacultyObs.subscribe(()=>{
      this.httpClientService.facultyList();
    });
  }

  facultyUpdate(id :number):void{
    this.router.navigate(['faculty/update',id]);
  }


}
